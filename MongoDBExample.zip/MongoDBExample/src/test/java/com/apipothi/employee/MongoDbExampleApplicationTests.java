package com.apipothi.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
